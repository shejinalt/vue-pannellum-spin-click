
## Changelog

### v0.5.0 - 2019/07/19

- Update dependency `pannellum` to `v2.5.2`

### v0.4.8 - 2019/05/29

- Limit pitch within -90 and 90.

### v0.4.7 - 2019/05/27

- Support `hotSpots`.

### v0.4.6 - 2019/05/14

- Fix an error on some mobile browser.

### v0.4.5 - 2019/05/08

- Fix image quality may be bad on some mobile browser.

### v0.4.4 - 2019/05/07

- Properties `hfov`, `yaw`, `pitch` can be two-way bound with `.sync` modifier now.
